<template>
  <div class="query">
    <div class="query-if">
      <!-- <div class="query-list">
                <label for="">股票：</label>
                <input type="text" v-model = 'gpname' placeholder="股票名称/代码">
            </div>  
            <div class="query-list">
                <label for="">入选时间：</label>
                <input type="text" v-model = 'time' placeholder="入选时间">
            </div>
            <div class="query-list">
                <label for="">入选理由：</label>
                <input type="text" v-model = 'reason' placeholder="入选理由">
      </div>-->
      <div class="query-btn">
        <button>查询</button>
      </div>
    </div>
    <div class="query-container">
      <div class="content">
        <el-table
          ref="multipleTable"
          :data="tableData"
          tooltip-effect="dark"
          style="width:100%"
          @selection-change="handleSelectionChange"
        >
          <el-table-colum type="selection" width="55"></el-table-colum>
          <el-table-colum prop="gpname" label="股票名称" width="120"></el-table-colum>
          <el-table-colum prop="gpcode" label="股票代码" width="120"></el-table-colum>
          <el-table-colum prop="gptime" label="创建时间" width="120"></el-table-colum>
          <el-table-colum prop="teacher" label="推荐老师" width="120"></el-table-colum>
          <el-table-colum prop="reason" label="入选理由" width="200"></el-table-colum>
        </el-table>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      tableData: [
        {
          gpname: "恒宝股份",
          gpcode: "002104",
          gptime: "2019-01-30 14:35",
          teacher: "曹向东",
          reason: "测试理由"
        },
        {
          gpname: "恒宝股份",
          gpcode: "002104",
          gptime: "2019-01-30 14:35",
          teacher: "曹向东",
          reason: "测试理由"
        },
        {
          gpname: "恒宝股份",
          gpcode: "002104",
          gptime: "2019-01-30 14:35",
          teacher: "曹向东",
          reason: "测试理由"
        }
      ],
      multipleSelection: []
    };
  },
  methods: {
    toggleSelection(rows) {
      if (rows) {
        rows.forEach(row => {
          this.$refs.multipleTable.toggleRowSelection(row);
        });
      } else {
        this.$refs.multipleTable.clearSelection();
      }
    },
    handleSelectionChange(val) {
      this.multipleSelection = val;
    }
  }
};
</script>
<style>
.query-if {
  overflow: hidden;
}
.query-list {
  float: left;
  margin: 0 14px 0 0;
}
.query-list input[placeholder] {
  color: #000;
}
.query-list input {
  width: 180px;
  height: 20px;
  line-height: 20px;
  padding-left: 4px;
}
.query-btn {
  float: left;
}
.query-btn button {
  width: 60px;
  height: 26px;
  line-height: 24px;
}
.query-container {
  margin-top: 20px;
}
</style>
