# 项目结构

- 视图层: component
- 控制层: page
- 逻辑层: store
