//Promise
import { Promise } from "es6-promise";
window.Promise = Promise;
