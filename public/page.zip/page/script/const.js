/**
 * 常量
 */
export const BASE_URL = "/";
