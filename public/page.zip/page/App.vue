<!--  -->
<template>
  <div class="app">
    <input type="text" v-model="total" />
    <ul>
      <li v-for="item in data" :key="item.name">name{{item.name}}</li>
    </ul>
    <page :total="total" :currentPage="currentPage" :size="size" @page="onPage"></page>
  </div>
</template>

<script>
import page from "./comps/page";
const data = {
  rows: [
    { name: 1 },
    { name: 2 },
    { name: 3 },
    { name: 4 },
    { name: 5 },
    { name: 6 },
    { name: 7 },
    { name: 8 },
    { name: 9 },
    { name: 10 }
  ],
  total: 10
};
export default {
  data() {
    return {
      total: data.total,
      size: 2,
      currentPage: 1
    };
  },
  components: { page },
  computed: {
    data() {
      return data.rows.slice(
        this.size * this.currentPage - this.size,
        this.size * this.currentPage
      );
    }
  },
  mounted() {},
  methods: {
    onPage(ops) {
      this.currentPage = ops;
      console.log("--onPage--", ops);
    }
  }
};
</script>
<style lang='scss' scoped>
.app {
  padding: 20px;
  input {
    padding: 5px 10px;
    margin-bottom: 20px;
  }
}
</style>
